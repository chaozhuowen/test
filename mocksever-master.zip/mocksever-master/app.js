require('babel-core/register');
var app = require('./mockroute/index');
module.exports = app;
